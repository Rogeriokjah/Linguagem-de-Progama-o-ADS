function CalcAreaCirculo (raio){
    var areacirculo = (parseFloat(raio) * parseFloat(raio) * 3.14).toFixed(2);

    return areacirculo;

}

//var testecirculo = CalcAreaCirculo (3);
//console.log(testecirculo);
