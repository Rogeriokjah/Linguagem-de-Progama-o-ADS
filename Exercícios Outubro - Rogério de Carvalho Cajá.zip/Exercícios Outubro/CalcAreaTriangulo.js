function CalcAreaTriangulo (base, altura) {
    var areatriangulo = ((parseFloat(base) * parseFloat(altura))/2).toFixed(2);

    return areatriangulo;

}

//var testearea = CalcAreaTriangulo(2,10);
//console.log(testearea);